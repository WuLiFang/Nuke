# -*- coding=UTF-8 -*-
"""Upload files to server.  """

from __future__ import (absolute_import, division, print_function,
                        unicode_literals)

from .view import Dialog
from .__main__ import main
