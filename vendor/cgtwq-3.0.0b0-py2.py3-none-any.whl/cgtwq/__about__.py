# -*- coding=UTF-8 -*-
"""CGTeamWork python client for humans.  """

__version__ = '3.0.0-beta.0'
__author__ = 'NateScarlet@Gmail.com'
