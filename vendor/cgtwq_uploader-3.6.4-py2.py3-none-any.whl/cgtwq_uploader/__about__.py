# -*- coding=UTF-8 -*-
# pyright: strict, reportTypeCommentUsage=none
"""CGTeamwork batch uploader.   """

from __future__ import absolute_import, division, print_function, unicode_literals

from .__version__ import VERSION as __version__
__author__ = 'NateScarlet@Gmail.com'
