# -*- coding=UTF-8 -*-
"""CGTeamwork batch uploader.   """

from __version__ import VERSION as __version__
__author__ = 'NateScarlet@Gmail.com'
