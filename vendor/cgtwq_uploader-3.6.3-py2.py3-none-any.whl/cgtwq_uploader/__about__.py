# -*- coding=UTF-8 -*-
"""CGTeamwork batch uploader.   """

__version__ = '3.6.0'
__author__ = 'NateScarlet@Gmail.com'
