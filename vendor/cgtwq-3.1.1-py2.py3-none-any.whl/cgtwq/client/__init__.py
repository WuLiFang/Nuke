# -*- coding=UTF-8 -*-
"""CGTeamWork client.  """

from __future__ import (absolute_import, division, print_function,
                        unicode_literals)

from .desktop import DesktopClient

__all__ = ['DesktopClient']
