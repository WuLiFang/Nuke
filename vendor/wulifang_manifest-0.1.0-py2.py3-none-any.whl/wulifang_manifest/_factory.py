# -*- coding=UTF-8 -*-
# type: ignore

from __future__ import absolute_import, division, print_function, unicode_literals


class _Factory:
    def new(self):
        raise NotImplementedError()


globals()["Factory"] = _Factory
