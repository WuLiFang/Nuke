# -*- coding=UTF-8 -*-
# pyright: strict, reportTypeCommentUsage=none

from __future__ import absolute_import, division, print_function, unicode_literals

TYPE_CHECKING = False
if TYPE_CHECKING:
    from typing import Text, Optional
    from ._manifest import Manifest

from ._util import atomic_save_path
from ._dumps import dumps
from ._resolve_path import resolve_path

import codecs


def save(manifest, path=None, crlf=True):
    # type: (Manifest,Optional[Text], bool) -> None
    if path is None and manifest.path:
        path = manifest.path
    else:
        path = resolve_path(path)
    data = dumps(manifest)
    if crlf:
        data = data.replace("\n", "\r\n")
    with atomic_save_path(path) as p:
        with codecs.open(p, "w", encoding="UTF-8") as f:
            f.write(data)
    return
