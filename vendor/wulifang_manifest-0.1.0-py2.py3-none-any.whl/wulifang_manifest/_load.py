# -*- coding=UTF-8 -*-
# pyright: strict, reportTypeCommentUsage=none

from __future__ import absolute_import, division, print_function, unicode_literals
import codecs
import os


TYPE_CHECKING = False
if TYPE_CHECKING:
    from typing import Text, Optional, Tuple

from ._manifest import Manifest
from ._resolve_path import resolve_path

from ._parse import parse
from ._util import is_file_not_found_error, TZ_UTC, NULL_TIME
from ._factory import Factory
from ._null_factory import NullFactory

from datetime import datetime


class _LoadFactory(Factory):
    def __init__(self, path, factory):
        # type: (Text, Optional[Factory]) -> None
        self.path = path
        self.factory = factory or NullFactory()

    def new(self):
        v = self.factory.new()
        if v.created_at == NULL_TIME or v.last_modified_at == NULL_TIME:
            stat = os.stat(self.path)
            if v.created_at == NULL_TIME:
                v.created_at = datetime.fromtimestamp(stat.st_ctime, TZ_UTC)
            if v.last_modified_at == NULL_TIME:
                v.last_modified_at = datetime.fromtimestamp(stat.st_mtime, TZ_UTC)
        return v


def _raw_load(
    path=None,
    factory=None,
    height=0,
    skip_validation=False,
):
    # type: (Optional[Text], Optional[Factory], int,bool) -> Tuple[Manifest, bool]
    path = resolve_path(path)
    ok = height == 0
    try:
        with codecs.open(path, "r", encoding="utf-8-sig") as f:
            raw = f.read()
        manifest = parse(
            raw,
            factory=_LoadFactory(path, factory),
            skip_validation=skip_validation or height > 0,
        )
        ok = True
    except Exception as ex:
        if not is_file_not_found_error(ex):
            raise
        manifest = (factory or NullFactory()).new()
    manifest.path = path

    current_dir = os.path.dirname(path)
    upper_dir = os.path.dirname(current_dir)
    if not manifest.root and current_dir != upper_dir:
        try:
            base, base_ok = _raw_load(upper_dir, height=height + 1)
            if not ok:
                return base, base_ok
            if base_ok:
                manifest.inherit(base)
        except Exception as ex:
            if not is_file_not_found_error(ex):
                raise
    return manifest, ok


def load(
    path=None,
    factory=None,
    skip_validation=False,
):
    # type: (Optional[Text], Optional[Factory], bool) -> Manifest
    m, _ = _raw_load(path, factory=factory, skip_validation=skip_validation)
    return m
