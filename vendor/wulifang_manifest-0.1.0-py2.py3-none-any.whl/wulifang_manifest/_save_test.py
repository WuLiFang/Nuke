# -*- coding=UTF-8 -*-
# pyright: strict, reportTypeCommentUsage=none

from __future__ import absolute_import, division, print_function, unicode_literals

TYPE_CHECKING = False
if TYPE_CHECKING:
    import pathlib
    from typing import Text

import wulifang_manifest as m6t
import os
from . import _test
from ._util import cast_text


def _read_toml(v):
    # type: (pathlib.Path) -> Text
    return v.read_bytes().decode("utf-8")


def test_should_able_to_save_to_cwd(tmp_path):
    # type: (pathlib.Path) -> None
    m = m6t.Manifest()
    m.created_by = "test"
    os.chdir(cast_text(tmp_path))
    m6t.save(m)
    _test.snapshot_match({"body": _read_toml(tmp_path / "wulifang.toml")})


def test_should_able_to_save_to_dir(tmp_path):
    # type: (pathlib.Path) -> None
    m = m6t.Manifest()
    m.created_by = "test"
    (tmp_path / "dir1").mkdir()
    m6t.save(m, cast_text(tmp_path / "dir1"))
    _test.snapshot_match({"body": _read_toml(tmp_path / "dir1" / "wulifang.toml")})


def test_should_able_to_save_to_file(tmp_path):
    # type: (pathlib.Path) -> None
    m = m6t.Manifest()
    m.created_by = "test"
    m6t.save(m, cast_text(tmp_path / "test.toml"))
    _test.snapshot_match({"body": _read_toml(tmp_path / "test.toml")})


def test_should_able_to_save_with_lf_eol(tmp_path):
    # type: (pathlib.Path) -> None
    m = m6t.Manifest()
    m.created_by = "test"
    m6t.save(m, cast_text(tmp_path / "test.toml"), crlf=False)
    _test.snapshot_match({"body": _read_toml(tmp_path / "test.toml")})
