# -*- coding=UTF-8 -*-
# pyright: strict, reportTypeCommentUsage=none

from __future__ import absolute_import, division, print_function, unicode_literals


TYPE_CHECKING = False
if TYPE_CHECKING:
    from typing import Text, Any, Optional, Dict, List

from ._factory import Factory
from ._manifest import Manifest
from ._vendor.tomlkit import parse as _toml_parse
from ._vendor.tomlkit.items import Table
from ._util import cast_text, cast_datetime, cast_list, cast_int, NULL_TIME
from .shot_matcher import FilenameRegex
from datetime import datetime
from ._null_factory import NullFactory
from ._errors import InvalidManifest


def _cast_table(v, key):
    # type: (Any, Text) -> Table
    assert isinstance(v, Table), "'%s' should be a Table." % (key,)
    return v


def _get_text(doc, key, d=""):
    # type: (Dict[Text,Any], Text, Text) -> Text
    if key not in doc:
        return d
    return cast_text(doc[key])


def _get_int(doc, key, d=0):
    # type: (Dict[Text,Any], Text, int) -> int
    if key not in doc:
        return d
    return cast_int(doc[key])


def _get_float(doc, key, d=0.0):
    # type: (Dict[Text,Any], Text, float) -> float
    if key not in doc:
        return d
    return float(doc[key])


def _get_time(doc, key, d=NULL_TIME):
    # type: (Dict[Text,Any], Text, datetime) -> datetime
    if key not in doc:
        return d
    return cast_datetime(doc[key])


def _get_bool(doc, key, d=False):
    # type: (Dict[Text,Any], Text,bool) -> bool
    if key not in doc:
        return d
    return bool(doc[key])


def _get_table(doc, key):
    # type: (Dict[Text,Any], Text) -> Optional[Table]
    if key not in doc:
        return

    return _cast_table(doc[key], key)


def _get_list(doc, key):
    # type: (Dict[Text,Any], Text) -> List[Any]
    if key not in doc:
        return []
    return cast_list(doc[key])


def parse(raw, factory=None, skip_validation=False):
    # type: (Text, Optional[Factory], bool) -> Manifest
    ret = (factory or NullFactory()).new()
    ret.raw = raw
    doc = _toml_parse(raw)
    ret.root = _get_bool(doc, "root")
    ret.schema_url = _get_text(doc, "schemaURL", ret.schema_url)
    ret.created_at = _get_time(doc, "createdAt", ret.created_at)
    ret.created_by = _get_text(doc, "createdBy", ret.created_by)
    ret.last_modified_at = _get_time(doc, "lastModifiedAt", ret.last_modified_at)
    ret.last_modified_by = _get_text(doc, "lastModifiedBy", ret.last_modified_by)
    v = _get_table(doc, "project")
    if v:
        ret.project.name = _get_text(v, "name")
        if "segment" in v:
            v2 = _cast_table(v["segment"], "project.segment")
            ret.project.segment.name = _get_text(v2, "name")

    v = _get_table(doc, "shot")
    if v:
        ret.shot.name = _get_text(v, "name")
        ret.shot.width = _get_int(v, "width")
        ret.shot.height = _get_int(v, "height")
        ret.shot.fps = _get_float(v, "fps")
        ret.shot.first_frame = _get_int(v, "firstFrame")
        ret.shot.frame_count = _get_int(v, "frameCount")

    v = _get_table(doc, "ocio")
    if v:
        ret.ocio.configPath = _get_text(v, "configPath")

    v = _get_table(doc, "cgteamwork")
    if v:
        ret.cgteamwork.database = _get_text(v, "database")
        ret.cgteamwork.module = _get_text(v, "module")
        if "pipeline" in v:
            v2 = _cast_table(v["pipeline"], "cgteamwork.pipeline")
            ret.cgteamwork.pipeline.id = _get_text(v2, "id")
        if "task" in v:
            v2 = _cast_table(v["task"], "cgteamwork.task")
            ret.cgteamwork.task.id = _get_text(v2, "id")

    for i in _get_list(doc, "shotMatcher"):  # type: ignore
        v2 = _cast_table(i, "shotMatcher.#")
        v3 = _get_table(v2, "filenameRegex")
        if v3:
            matcher = FilenameRegex(
                _get_text(v3, "pattern"), _get_text(v3, "replacement", "")
            )
            ret.shotMatcher.append(matcher)
        else:
            raise ValueError("unsupported shotMatcher")

    v = _get_table(doc, "software")
    if v:
        v2 = _get_table(v, "nuke")
        if v2:
            ret.software.nuke.major = _get_int(v2, "major")
            ret.software.nuke.minor = _get_int(v2, "minor")
            ret.software.nuke.release = _get_int(v2, "release")

    v = _get_table(doc, "extension")
    if v:
        for k, v in v.items():  # type: ignore
            ret.extension[cast_text(k)] = _cast_table(v, "extension.%s" % (k,))
    if not skip_validation and not ret.valid():
        raise InvalidManifest()
    return ret
