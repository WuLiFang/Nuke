# -*- coding=UTF-8 -*-
# pyright: strict, reportTypeCommentUsage=none

from __future__ import absolute_import, division, print_function, unicode_literals


TYPE_CHECKING = False
if TYPE_CHECKING:
    from typing import Text, Dict, Any

from ._manifest import Manifest
from ._vendor.tomlkit import parse, dumps as _toml_dumps
from .shot_matcher import FilenameRegex
from ._util import cast_list, iterkeys
from collections import OrderedDict
from ._errors import InvalidManifest

_HEADER = """\
# 吾立方清单文件，详细说明见 schemaURL。
"""


def _set_default_dict(d, k):
    # type: (Dict[Text,Any], Text) -> Dict[Text,Any]
    v = d.setdefault(k, OrderedDict())
    assert isinstance(v, dict), "should be a dict"
    return v  # type: ignore


def _dict_set(d, k, v, base):
    # type: (Dict[Text,Any], Any, Any, Any) -> None
    if v == base:
        d.pop(k, None)
        return
    d[k] = v


def _should_prune(v):
    # type: (Any) -> bool
    return not v


def _dict_prune(d):
    # type: (Dict[Text,Any]) -> None
    for i in [i for i in iterkeys(d) if _should_prune(d[i])]:
        del d[i]


def dumps(manifest, skip_validation=False):
    # type: (Manifest,bool) -> Text
    if not skip_validation and not manifest.valid():
        raise InvalidManifest()
    raw = manifest.raw.replace("\r\n", "\n")
    if _HEADER not in raw:
        raw = _HEADER + raw
    doc = parse(raw)
    base = manifest.base or Manifest()

    doc["schemaURL"] = manifest.schema_url
    _dict_set(doc, "root", manifest.root, False)
    doc["createdAt"] = manifest.created_at
    doc["createdBy"] = manifest.created_by
    doc["lastModifiedAt"] = manifest.last_modified_at
    doc["lastModifiedBy"] = manifest.last_modified_by or manifest.created_by

    v = manifest.project.segment
    b = base.project.segment
    m = _set_default_dict(_set_default_dict(doc, "project"), "segment")
    _dict_set(m, "name", v.name, b.name)
    _dict_prune(m)

    v = manifest.project
    b = base.project
    m = _set_default_dict(doc, "project")
    _dict_set(m, "name", v.name, b.name)
    _dict_prune(m)

    v = manifest.shot
    b = base.shot
    m = _set_default_dict(doc, "shot")
    _dict_set(m, "name", v.name, b.name)
    _dict_set(m, "width", v.width, b.width)
    _dict_set(m, "height", v.height, b.height)
    _dict_set(m, "fps", v.fps, b.fps)
    _dict_set(m, "firstFrame", v.first_frame, b.first_frame)
    _dict_set(m, "frameCount", v.frame_count, b.frame_count)
    _dict_prune(m)

    v = manifest.ocio
    b = base.ocio
    m = _set_default_dict(doc, "ocio")
    _dict_set(m, "configPath", v.configPath, b.configPath)
    _dict_prune(m)

    v = manifest.cgteamwork
    b = base.cgteamwork
    m = _set_default_dict(doc, "cgteamwork")
    _dict_set(m, "database", v.database, b.database)
    _dict_set(m, "module", v.module, b.module)
    v2 = v.pipeline
    b2 = b.pipeline
    if v2:
        m2 = _set_default_dict(m, "pipeline")
        _dict_set(m2, "id", v2.id, b2.id)
        _dict_prune(m2)
    v2 = v.task
    b2 = b.task
    if v2:
        m2 = _set_default_dict(m, "task")
        _dict_set(m2, "id", v2.id, b2.id)
        _dict_prune(m2)
    _dict_prune(m)

    v = manifest.software
    b = base.software
    m = _set_default_dict(doc, "software")
    v2 = v.nuke
    b2 = b.nuke
    if v2:
        m2 = _set_default_dict(m, "nuke")
        _dict_set(m2, "major", v2.major, b2.major)
        _dict_set(m2, "minor", v2.minor, b2.minor)
        _dict_set(m2, "release", v2.release, b2.release)
        _dict_prune(m2)
    _dict_prune(m)

    v = manifest.shotMatcher
    b = base.shotMatcher
    if v != b:
        array = cast_list(doc.get("shotMatcher", []))  # type: ignore
        for index, i in enumerate(manifest.shotMatcher):
            if index > len(array) - 1:
                array.append({})
            m = array[index]
            if isinstance(i, FilenameRegex):
                m = _set_default_dict(m, "filenameRegex")
                m["pattern"] = i.pattern
                _dict_set(m, "replacement", i.replacement, "")
            else:
                raise NotImplementedError("%s is not supported" % (i,))
        doc["shotMatcher"] = array

    v = manifest.extension
    b = base.extension
    for i, v in v.items():
        if i in b and b[i] == v:
            continue
        m = _set_default_dict(doc, "extension")
        m[i] = v

    _dict_prune(doc)

    return _toml_dumps(doc).replace("\r\n", "\n")
