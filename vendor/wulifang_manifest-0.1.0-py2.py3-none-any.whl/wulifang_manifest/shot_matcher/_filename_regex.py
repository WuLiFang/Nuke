# -*- coding=UTF-8 -*-
# pyright: strict, reportTypeCommentUsage=none

from __future__ import absolute_import, division, print_function, unicode_literals
import os
import re

TYPE_CHECKING = False
if TYPE_CHECKING:
    from typing import Text


from ._shot_matcher import ShotMatcher


class FilenameRegex(ShotMatcher):
    def __init__(self, pattern, replacement=""):
        # type: (Text, Text) -> None
        self.pattern = pattern
        self.replacement = replacement

    def valid(self):
        if not self.pattern:
            return False
        return True

    def match(self, filename):
        # type: (Text) -> Text
        if not self.valid():
            return ""
        v, _ = os.path.splitext(os.path.basename(filename))
        if not re.match(self.pattern, v):
            return ""
        if self.replacement:
            return re.sub(self.pattern, self.replacement, v)
        return v
