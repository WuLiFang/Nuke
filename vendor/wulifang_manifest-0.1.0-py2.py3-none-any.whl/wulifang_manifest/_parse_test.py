# -*- coding=UTF-8 -*-
# pyright: strict, reportTypeCommentUsage=none

from __future__ import absolute_import, division, print_function, unicode_literals


import wulifang_manifest as m6t
from . import _test


def test_should_get_known_fields():
    p = _test.data_path("sample1.toml")
    raw = _test.read_text(p)
    m = m6t.parse(raw)
    assert raw == m.raw
    m.raw = ""
    _test.snapshot_match(m6t.dumps(m))
