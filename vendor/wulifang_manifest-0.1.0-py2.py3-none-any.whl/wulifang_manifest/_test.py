# -*- coding=UTF-8 -*-
# pyright: strict, reportTypeCommentUsage=none

from __future__ import absolute_import, division, print_function, unicode_literals

TYPE_CHECKING = False
if TYPE_CHECKING:
    from typing import (
        Callable,
        Optional,
        Tuple,
        Text,
    )

import codecs
import inspect
import json
import os

from ._util import cast_text, is_file_not_found_error, iteritems


DATA_PATH = os.path.join(os.path.dirname(__file__), "test_data")

SNAPSHOT_UPDATE = os.getenv("SNAPSHOT_UPDATE", "").lower() == "true"


def data_path(*paths):
    # type: (Text) -> Text
    return os.path.join(DATA_PATH, *paths)


def read_text(path):
    # type: (Text) -> Text
    with codecs.open(path, "r", encoding="utf-8") as f:
        return f.read()


def _json_transform(v):
    # type: (object) -> object
    if isinstance(v, dict):
        return {cast_text(k): _json_transform(v) for k, v in iteritems(v)}  # type: ignore
    if isinstance(v, (list, tuple)):
        return [_json_transform(i) for i in v]  # type: ignore
    if isinstance(v, (int, float)):
        return v
    return cast_text(v)


def _default_encode(v):
    # type: (object) -> Tuple[Text, Text]
    if isinstance(v, (list, tuple, int, float, dict)):
        return (
            cast_text(
                json.dumps(
                    v,
                    default=_json_transform,
                    indent=2,
                    ensure_ascii=False,
                )
            ),
            ".json",
        )

    return cast_text(v), ".txt"


def toml_encode(v):
    # type: (object) -> Tuple[Text, Text]
    return cast_text(v), ".toml"


def snapshot_match(
    v,
    name="",
    encode=_default_encode,
    assert_match=None,
    update=SNAPSHOT_UPDATE,
    skip=0,
):
    # type: (object, Text,  Callable[[object], Tuple[Text, Text]], Optional[Callable[[Text, Text], None]] , bool, int ) -> None
    actual, ext = encode(v)

    def _assert_match(a, b):
        # type: (Text, Text) -> None
        if assert_match:
            assert_match(a, b)
        elif ext == ".json":
            json_a = json.loads(a)
            json_b = json.loads(b)
            assert json_a == json_b, (json_a, json_b)
        else:
            assert b == a, (a, b)

    _, filename, _, func_name, _, _ = inspect.stack()[skip + 1]
    data_dir = os.path.join(os.path.dirname(filename), "__snapshots__")
    key = func_name
    if name:
        key += "." + name
    save_path = os.path.join(
        data_dir,
        os.path.splitext(os.path.basename(filename))[0],
        key + ext,
    )

    def _update():
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        with codecs.open(save_path, "w", encoding="utf8") as f:
            f.write(actual)

    if update:
        _update()
        return
    try:
        with codecs.open(save_path, "r", encoding="utf8") as f:
            expected = f.read()
        _assert_match(expected, actual)
    except Exception as ex:
        if not is_file_not_found_error(ex):
            raise
        _update()
