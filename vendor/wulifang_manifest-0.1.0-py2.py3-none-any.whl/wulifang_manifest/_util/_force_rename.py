# -*- coding=UTF-8 -*-
# pyright: strict, reportTypeCommentUsage=none

from __future__ import absolute_import, division, print_function, unicode_literals

TYPE_CHECKING = False
if TYPE_CHECKING:
    from typing import Text

import os
from ._is_file_exists_error import is_file_exists_error


def force_rename(src, dst):
    # type: (Text, Text) -> None
    try:
        os.rename(src, dst)
    except Exception as ex:
        if not is_file_exists_error(ex):
            raise
        os.unlink(dst)
        os.rename(src, dst)
