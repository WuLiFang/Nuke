# -*- coding=UTF-8 -*-
# pyright: strict, reportTypeCommentUsage=none

from __future__ import absolute_import, division, print_function, unicode_literals

TYPE_CHECKING = False
if TYPE_CHECKING:
    from typing import Text, Generator


import contextlib
from ._force_rename import force_rename
import os
import tempfile


@contextlib.contextmanager
def atomic_save(
    __path,
    __temp_suffix=".tmp",
    __backup_suffix="",
):
    # type: (Text, Text, Text) -> Generator[tuple[int, Text]]
    fd, tmp_path = tempfile.mkstemp(
        __temp_suffix,
        os.path.basename(__path),
        os.path.dirname(__path),
    )
    backup_path = ""
    did_backup = False
    try:
        yield fd, tmp_path
        if __backup_suffix:
            backup_path = __path + __backup_suffix
            try:
                os.link(__path, backup_path)
                did_backup = True
            except FileNotFoundError:
                pass
            except FileExistsError:
                os.remove(backup_path)
                os.link(__path, backup_path)
        force_rename(tmp_path, __path)
        if did_backup:
            os.remove(backup_path)
    finally:
        os.close(fd)
