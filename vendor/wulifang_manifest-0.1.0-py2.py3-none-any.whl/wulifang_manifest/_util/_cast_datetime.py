# -*- coding=UTF-8 -*-
# pyright: strict, reportTypeCommentUsage=none

from __future__ import absolute_import, division, print_function, unicode_literals
from datetime import datetime, date, time


TYPE_CHECKING = False
if TYPE_CHECKING:
    from typing import Any

from .._vendor.tomlkit._utils import parse_rfc3339

from ._compat import text_type


def cast_datetime(v):
    # type: (Any) -> datetime
    if isinstance(v, datetime):
        return v
    if isinstance(v, date):
        return datetime(
            v.year,
            v.month,
            v.day,
        )
    if isinstance(v, time):
        t = datetime.today()
        return datetime(
            t.year,
            t.month,
            t.day,
            v.hour,
            v.minute,
            v.second,
            v.microsecond,
            v.tzinfo,
        )

    return cast_datetime(parse_rfc3339(text_type(v)))
