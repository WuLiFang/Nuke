# -*- coding=UTF-8 -*-
# pyright: strict, reportTypeCommentUsage=none

from __future__ import absolute_import, division, print_function, unicode_literals


import os
import wulifang_manifest as m6t

from . import _test


def test_should_handle_file():
    p = _test.data_path("sample1.toml")
    m = m6t.load(p)
    assert m.path == p
    assert not m.base

    _test.snapshot_match(m6t.dumps(m))


def test_should_handle_dir():
    p = _test.data_path("sample2")
    m = m6t.load(p)
    assert m.path == os.path.join(p, "wulifang.toml")
    assert not m.base

    _test.snapshot_match(m6t.dumps(m))


def test_should_use_upper_as_default():
    p = _test.data_path("sample3", "dir1")
    m = m6t.load(p)
    assert m.project.name == "测试"
    assert m.path == _test.data_path("sample3", "dir1", "wulifang.toml")
    assert m.base
    assert m.base.path == _test.data_path("sample3", "wulifang.toml")
    _test.snapshot_match(m6t.dumps(m))


def test_should_handle_root():
    m = m6t.load(
        _test.data_path("sample4/dir1"),
    )
    assert m.project.name == ""
    _test.snapshot_match(m6t.dumps(m))


def test_should_handle_extension_inherit():
    m = m6t.load(
        _test.data_path("sample5/dir1"),
    )
    e1 = m.extension["00000000-0000-0000-0000-000000000001"]
    e2 = m.extension["00000000-0000-0000-0000-000000000002"]
    e3 = m.extension["00000000-0000-0000-0000-000000000003"]
    assert e1["a"] == "child"
    assert "b" not in e1
    assert e2["a"] == "child"
    assert e3["a"] == "parent"
    _test.snapshot_match(m6t.dumps(m))


def test_should_skip_empty_base():
    m = m6t.load(
        _test.data_path("sample9", "a", "b"),
    )
    assert m.base
    assert not m.base.base
    assert m.path == _test.data_path("sample9", "a", "b", "wulifang.toml")
    assert m.base.path == _test.data_path("sample9", "wulifang.toml")
    _test.snapshot_match(m6t.dumps(m))


def test_should_preserve_path_when_file_not_exist():
    m = m6t.load(
        _test.data_path("sample9", "a"),
    )
    assert m.base
    assert not m.base.base
    assert m.path == _test.data_path("sample9", "a", "wulifang.toml")
    _test.snapshot_match(m6t.dumps(m, skip_validation=True))


def test_should_preserve_path_when_file_not_exist_and_no_upper():
    m = m6t.load(
        _test.data_path("not_exist"),
    )
    assert not m.base
    _test.snapshot_match(m6t.dumps(m, skip_validation=True))


def test_should_allow_invalid_base_manifest():
    m = m6t.load(
        _test.data_path("sample10", "a", "b"),
    )
    assert m.base
    assert not m.base.base
    assert m.project.name == "test"
    _test.snapshot_match(m6t.dumps(m))
