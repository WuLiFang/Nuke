# -*- coding=UTF-8 -*-
# pyright: strict, reportTypeCommentUsage=none

from __future__ import absolute_import, division, print_function, unicode_literals

TYPE_CHECKING = False
if TYPE_CHECKING:
    from typing import Text, Optional

import os

_sep = tuple(i for i in (os.path.sep, os.path.altsep) if i)


def resolve_path(path=None):
    # type: (Optional[Text]) -> Text
    path = path or os.path.join(os.getcwd(), "wulifang.toml")
    if path.endswith(_sep) or os.path.isdir(path):
        path = os.path.join(path, "wulifang.toml")
    return path
