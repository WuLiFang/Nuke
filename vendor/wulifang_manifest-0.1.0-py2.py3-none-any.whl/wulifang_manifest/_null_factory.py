# -*- coding=UTF-8 -*-
# pyright: strict, reportTypeCommentUsage=none

from __future__ import absolute_import, division, print_function, unicode_literals

from ._manifest import Manifest
from ._factory import Factory


class NullFactory(Factory):
    def new(self):
        # type: () -> Manifest
        return Manifest()
