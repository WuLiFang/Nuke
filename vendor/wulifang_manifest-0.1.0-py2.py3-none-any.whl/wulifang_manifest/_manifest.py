# -*- coding=UTF-8 -*-
# pyright: strict, reportTypeCommentUsage=none

from __future__ import absolute_import, division, print_function, unicode_literals


TYPE_CHECKING = False
if TYPE_CHECKING:
    from typing import Text, List, Any, Dict, Optional
    from .shot_matcher import ShotMatcher

from ._util import NULL_TIME, iteritems
import re
from collections import OrderedDict

from copy import copy, deepcopy


class _ProjectSegment:
    def __init__(self):
        self.name = ""

    def valid(self):
        if not self.name:
            return False
        return True

    def copy(self):
        return copy(self)


class _Project:
    def __init__(self):
        self.name = ""
        self.segment = _ProjectSegment()

    def valid(self):
        if not self.name:
            return False
        return True

    def copy(self):
        obj = copy(self)
        obj.segment = obj.segment.copy()
        return obj


class _Shot:
    def __init__(self):
        self.name = ""
        self.width = 0
        self.height = 0
        self.fps = 0.0
        self.first_frame = 0
        self.frame_count = 0

    def valid(self):
        if self.name:
            return True
        return False

    def copy(self):
        return copy(self)


class _OCIO:
    def __init__(self):
        self.configPath = ""

    def __bool__(self):
        if self.configPath:
            return True
        return False

    __nonzero__ = __bool__

    def copy(self):
        return copy(self)


class _CGTeamworkPipeline:
    def __init__(self):
        self.id = ""

    def valid(self):
        if not self.id:
            return False
        return True

    def copy(self):
        return copy(self)


class _CGTeamworkTask:
    def __init__(self):
        self.id = ""

    def valid(self):
        if not self.id:
            return False
        return True

    def copy(self):
        return copy(self)


class _CGTeamwork:
    def __init__(self):
        self.database = ""
        self.module = ""
        self.pipeline = _CGTeamworkPipeline()
        self.task = _CGTeamworkTask()

    def valid(self):
        if not self.database:
            return False
        if not self.module:
            return False
        return True

    def copy(self):
        obj = copy(self)
        obj.pipeline = obj.pipeline.copy()
        obj.task = obj.task.copy()
        return obj


class _SoftwareNuke:
    def __init__(self):
        self.major = 0
        self.minor = 0
        self.release = 0

    def __bool__(self):
        if self.major:
            return True
        return False

    __nonzero__ = __bool__

    def copy(self):
        return copy(self)


class _Software:
    def __init__(self):
        self.nuke = _SoftwareNuke()

    def __bool__(self):
        if self.nuke:
            return True
        return False

    __nonzero__ = __bool__

    def copy(self):
        obj = copy(self)
        obj.nuke = obj.nuke.copy()
        return obj


class _Extension:
    _key_pattern = re.compile(
        r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"
    )

    def __init__(self):
        self._d = OrderedDict()  # type: Dict[Text, Dict[Text, Any]]

    def _validate_key(self, key):
        # type: (Text) -> None
        if not self._key_pattern.match(key):
            raise ValueError("extension key must be a uuid")
        return

    def __getitem__(self, key):
        # type: (Text) -> Dict[Text, Any]
        return self._d[key]

    def __setitem__(self, k, v):
        # type: (Text, Dict[Text, Any]) -> None
        self._validate_key(k)
        if not v:
            if k in self._d:
                del self._d[k]
            return
        self._d[k] = v

    def __contains__(self, k):
        # type: (Text) -> bool
        return k in self._d

    def setdefault(self, k, v):
        # type: (Text, Dict[Text,Any]) -> Dict[Text, Any]
        self._validate_key(k)
        return self._d.setdefault(k, v)

    def items(self):
        return iteritems(self._d)

    def copy(self):
        obj = copy(self)
        obj._d = deepcopy(obj._d)
        return obj


class Manifest:
    def __init__(self):
        # type: () -> None

        self.path = ""
        self.raw = ""
        self.base = None  # type: Optional[Manifest]

        self.root = False
        self.schema_url = "https://git.wlf.com/WuLiFang/manifest"
        self.created_at = NULL_TIME
        self.created_by = ""
        self.last_modified_at = self.created_at
        self.last_modified_by = ""
        self.project = _Project()
        self.shot = _Shot()
        self.ocio = _OCIO()
        self.cgteamwork = _CGTeamwork()
        self.shotMatcher = []  # type: List[ShotMatcher]
        self.software = _Software()
        self.extension = _Extension()

    def valid(self):
        # type: () -> bool
        if not self.schema_url:
            return False
        if not self.created_by:
            return False
        return True

    def copy(self):
        obj = copy(self)
        obj.project = obj.project.copy()
        obj.shot = obj.shot.copy()
        obj.ocio = obj.ocio.copy()
        obj.cgteamwork = obj.cgteamwork.copy()
        obj.shotMatcher = obj.shotMatcher.copy()
        obj.software = obj.software.copy()
        obj.extension = obj.extension.copy()
        return obj

    def inherit(self, base):
        # type: (Manifest) -> None
        if self.base and self.base != base:
            raise ValueError("multiple inherit is not allowed")
        self.base = base

        a, b = self.project, base.project
        a.name = a.name or b.name

        a, b = self.project.segment, base.project.segment
        a.name = a.name or b.name

        a, b = self.shot, base.shot
        a.name = a.name or b.name
        a.width = a.width or b.width
        a.height = a.height or b.height
        a.fps = a.fps or b.fps
        a.first_frame = a.first_frame or b.first_frame
        a.frame_count = a.frame_count or b.frame_count

        a, b = self.ocio, base.ocio
        a.configPath = a.configPath or b.configPath

        a, b = self.cgteamwork, base.cgteamwork
        a.database = a.database or b.database
        a.module = a.module or b.module

        a, b = self.cgteamwork.pipeline, base.cgteamwork.pipeline
        a.id = a.id or b.id

        a, b = self.cgteamwork.task, base.cgteamwork.task
        a.id = a.id or b.id

        a, b = self, base
        a.shotMatcher = a.shotMatcher or b.shotMatcher

        a, b = self.software.nuke, base.software.nuke
        a.major = a.major or b.major
        a.minor = a.minor or b.minor
        a.release = a.release or b.release

        a, b = self.extension, base.extension
        for k, v in b.items():
            if k not in a:
                a[k] = v
        return
