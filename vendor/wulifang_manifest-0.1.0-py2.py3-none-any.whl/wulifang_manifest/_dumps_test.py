# -*- coding=UTF-8 -*-
# pyright: strict, reportTypeCommentUsage=none

from __future__ import absolute_import, division, print_function, unicode_literals

import wulifang_manifest as m6t
from . import _test


def test_should_add_comment():
    m = m6t.Manifest()
    m.created_by = "test"
    data = m6t.dumps(m)
    _test.snapshot_match(data)


def test_should_preserve_comment():
    p = _test.data_path("sample6")
    m = m6t.load(p)
    m.project.name = "test"
    data = m6t.dumps(m)
    _test.snapshot_match(data)


def test_should_drop_empty_section():
    p = _test.data_path("sample6")
    m = m6t.load(p)
    m.project.name = ""
    data = m6t.dumps(m)
    _test.snapshot_match(data)


def test_should_drop_redundant_section():
    p = _test.data_path("sample7", "dir1")
    m = m6t.load(p)
    m.project.name = ""
    data = m6t.dumps(m)
    _test.snapshot_match(data)


def test_should_preserve_future_field():
    p = _test.data_path("sample8")
    m = m6t.load(p)
    data = m6t.dumps(m)
    _test.snapshot_match(data)


def test_should_only_add_header_once():
    p = _test.data_path("sample1.toml")
    m = m6t.load(p)
    data = m6t.dumps(m6t.parse(m6t.dumps(m).replace("\n", "\r\n")))
    _test.snapshot_match([data])


def test_should_set_known_field():
    p = _test.data_path("sample1.toml")
    m = m6t.load(p)
    m.raw = ""
    data = m6t.dumps(m)
    _test.snapshot_match(data)
