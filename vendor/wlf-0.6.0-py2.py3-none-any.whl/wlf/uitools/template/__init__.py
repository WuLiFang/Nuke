# -*- coding=UTF-8 -*-
"""UI template.  """
